const express = require('express');
const connectToDatabase = require('./db');
const userRoutes = require('./userRoutes');

const app = express();
const PORT = 3000;

// Connect to MongoDB
connectToDatabase();

// Middleware
app.use(express.json());

// Routes
app.use('/api', userRoutes);

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});